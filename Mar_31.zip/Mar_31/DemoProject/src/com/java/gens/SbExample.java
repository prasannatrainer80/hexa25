package com.java.gens;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Welcome to Java...\n");
		sb.append("Trainer Prasanna...\n");
		sb.append("From Hexaware Training...\n");
		System.out.println(sb);
	}
}
