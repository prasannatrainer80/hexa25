package com.java.gens;

public class NegativeException extends Exception {

	NegativeException(String error) {
		super(error);
	}
}
