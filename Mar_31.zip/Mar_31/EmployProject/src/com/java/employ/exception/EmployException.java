package com.java.employ.exception;

public class EmployException extends Exception {

	public EmployException(String error) {
		super(error);
	}
}
