package com.java.day1;

public class Data {

	private void sayHello() {
		System.out.println("Welcome to Java Programming...");
	}
	
	public void company() {
		System.out.println("Company is Hexaware...");
	}
	
	void trainer() {
		System.out.println("Trainer is Prasanna...");
	}
}
