package com.java.day1;

public class Demo {
	public static void main(String[] args) {
		Data data = new Data();
		data.company();
		data.trainer();
	}
}
