package com.java.day1;

public class StrEx4 {

	public static void main(String[] args) {
		String str="Hello";
		String res = str.concat(" World");
		System.out.println("Immutable " +str);
		System.out.println(res);
	}
}
