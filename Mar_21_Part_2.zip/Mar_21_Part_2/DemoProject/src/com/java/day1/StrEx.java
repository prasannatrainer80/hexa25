package com.java.day1;

public class StrEx {

	public static void main(String[] args) {
		String s1 = "Hemanth", s2 = "Anish", s3 = "Gopal", s4="Hemanth";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		
	}
}
