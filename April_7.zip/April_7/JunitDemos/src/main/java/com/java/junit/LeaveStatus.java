package com.java.junit;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED
}
