package com.java.junit;

public enum LeaveType {
	EL, PL, ML
}
