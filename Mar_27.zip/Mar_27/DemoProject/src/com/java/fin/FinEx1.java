package com.java.fin;

public class FinEx1 {

	public static void main(String[] args) {
		final String str = "Welcome";
		str="Hi";
	}
}
