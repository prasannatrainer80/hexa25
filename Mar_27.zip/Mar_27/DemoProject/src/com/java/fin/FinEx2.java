package com.java.fin;

final class Hello {
	public void show() {
		System.out.println("Hi");
	}
}

class Test extends Hello {
	
}

public class FinEx2 {

}
