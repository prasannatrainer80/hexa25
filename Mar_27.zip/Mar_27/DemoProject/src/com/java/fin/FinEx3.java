package com.java.fin;

class C1 {
	
	public final void show() {
		System.out.println("Show From C1...");
	}
}

class C2 extends C1 {
	public void show() {
		
	}
}

public class FinEx3 {

}
