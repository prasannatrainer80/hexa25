package com.java.abs;

public class Cow extends Animal {

	@Override
	public void name() {
		System.out.println("Name is Cow...");
	}

	@Override
	public void type() {
		System.out.println("Cow is of Mammals Category...");
	}

}
