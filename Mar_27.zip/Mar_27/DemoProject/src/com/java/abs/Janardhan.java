package com.java.abs;

public class Janardhan extends Training {

	@Override
	void name() {
		System.out.println("Name is Janardhan...");
	}

	@Override
	void email() {
		System.out.println("Email is janardhan@gmail.com");
	}

}
