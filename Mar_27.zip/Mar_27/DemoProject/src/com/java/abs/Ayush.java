package com.java.abs;

public class Ayush extends Training {

	@Override
	void name() {
		System.out.println("Name is Ayush...");
	}

	@Override
	void email() {
		System.out.println("Email is Ayush@gmail.com");
	}

}
