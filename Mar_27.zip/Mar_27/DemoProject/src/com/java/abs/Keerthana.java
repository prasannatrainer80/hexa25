package com.java.abs;

public class Keerthana extends Training {

	@Override
	void name() {
		System.out.println("Name is Keerthana...");
	}

	@Override
	void email() {
		System.out.println("Email is keerthana@gmail.com");
	}

}
