package com.java.day1;

public class Example1 {

	public static void main(String[] args) {
		int x=12;
		double b=12.5;
		String str="Welcome to Java";
		
		System.out.println("X value is  " +x);
		System.out.println("B value  " +b);
		System.out.println("Name is  " +str);
	}
}
