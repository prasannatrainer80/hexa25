package com.java.lms;

import org.junit.Test;

import com.java.lms.model.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
