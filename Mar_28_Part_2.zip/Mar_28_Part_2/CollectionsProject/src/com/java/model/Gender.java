package com.java.model;

public enum Gender {
	MALE, FEMALE
}
