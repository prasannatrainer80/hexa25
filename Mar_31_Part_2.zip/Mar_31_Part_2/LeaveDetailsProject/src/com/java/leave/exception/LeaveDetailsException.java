package com.java.leave.exception;

public class LeaveDetailsException extends Exception {

	public LeaveDetailsException(String error) {
		super(error);
	}
}
